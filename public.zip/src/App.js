import React from 'react';
import Home from "./pages/home/Home"
import Addshift from './pages/shift/shiftTiming/Addshift/Addshift';
import{
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";


 
function App() {
  return (
    <div className="App">
      <Router>
         <Routes>
          <Route path="/">
            <Route index element={<Home/>}></Route>
            <Route path="shift">
            <Route path="new" element={<Addshift/>}/>
            </Route>
          </Route>
         </Routes>      
    </Router>
    </div>
  );
}

export default App;
